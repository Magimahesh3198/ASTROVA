"""
config 
"""
config = {
    "APPID": "axa3bee63c35434eee",
    "APPSecret": "57c8ada3e1d84ebb9d2f865a56d2c515",
    "Authorization": "APPCODE e63f72531dd14ea2aa9959730861cb10",
    "URLPrefix": "https://apiglobal.autoxing.com",
    "telegram_bot_token": "8143266327:AAGSoF0-9DeBtCybVaIhGpLsQH6JyjVxmmg",

    "token": "eyJhbGciOiJSUzI1NiIsImtpZCI6InVuaXFfa2V5In0.eyJqdGkiOiJXOFA1dEwtMnNNM2JQN2JsNnl2UndBIiwiaWF0IjoxNzQ3NjQ5NzY3LCJleHAiOjE3NDgyNTM1NjcsIm5iZiI6MTc0NzY0OTcwNywic3ViIjoiTVlfU1VCSkVDVCIsImF1ZCI6Ik1ZX0FVRElFTkNFIiwiYXBwSWQiOiJheGEzYmVlNjNjMzU0MzRlZWUiLCJhcHBTZWNyZXQiOiI1N2M4YWRhM2UxZDg0ZWJiOWQyZjg2NWE1NmQyYzUxNSIsIm9wZW5JZCI6IjgwMDMyYmNhZjE1Njk3ZjJlOTMzZjYwMzVhOGFjN2JkIiwia2V5Ijoiand0LWF1dGgifQ.okUCF4ciUaZH4P0tQDXCWLvxXNXA65LmAGYgv1h_A7CALkwMIJUCGw3mp4knLLcOGiRdFV0HiP4EjbYyQq6-anEpxiVu3Kp3_tT9igjumA50AWacixLPeqRHRWOql099Qrog2-xepLrkh-Fv4EBb-D7a073atjuixOb0n7_9hEd4qxV9zft-f-0EUyjQYMZtg4xuOw7JnTMOitvaxVqmLx3KOeEEgrAV54chJItamhdO3ROqPnZzrQhjpdCzghwTr-Q_99OlvCgIDrZBTS8O-rHXsetMEkUkrefI1QgJEpLpPX3XtQ36B_9PRavPCaDwzDZM91FJ-KbabT81GXTOtQ"
}




